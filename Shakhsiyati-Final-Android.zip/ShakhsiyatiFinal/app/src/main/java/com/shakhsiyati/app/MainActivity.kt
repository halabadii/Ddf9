package com.shakhsiyati.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val categories = listOf("الجسم","الصحة","النوم","العقل","التعلم","الانضباط","الثقة","العلاقات","المال","المهارات","الروح","الراحة")
private val emojis = listOf("💪","❤️","🌙","🧠","📚","⚔️","🔥","🤝","💰","🛠️","✨","🌿")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ShakhsiyatiApp(this) } }
}

private fun levelOf(v: Int) = (v / 10) + 1
private fun overallLevel(xp: Int) = (xp / 1000) + 1
private fun xpIntoLevel(xp: Int) = xp % 1000

@Composable fun ShakhsiyatiApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("shakhsiyati", Context.MODE_PRIVATE) }
    var values by remember { mutableStateOf(categories.map { prefs.getInt("s_$it", 35) }) }
    var mood by remember { mutableIntStateOf(prefs.getInt("mood", 60)) }
    var name by remember { mutableStateOf(prefs.getString("name", "المغامر") ?: "المغامر") }
    var xp by remember { mutableIntStateOf(prefs.getInt("xp", 0)) }
    var streak by remember { mutableIntStateOf(prefs.getInt("streak", 0)) }
    var savedToday by remember { mutableStateOf(prefs.getBoolean("saved_today", false)) }
    var tab by remember { mutableIntStateOf(0) }

    fun saveDay() {
        val oldAvg = prefs.getInt("last_avg", values.average().roundToInt())
        val newAvg = values.average().roundToInt()
        val improvement = (newAvg - oldAvg).coerceAtLeast(0)
        val gained = 50 + improvement * 10 + (mood / 10)
        xp += gained
        streak = if (savedToday) streak else streak + 1
        val e = prefs.edit()
        categories.forEachIndexed { i, c -> e.putInt("s_$c", values[i]) }
        e.putInt("mood", mood).putInt("xp", xp).putInt("streak", streak)
            .putInt("last_avg", newAvg).putBoolean("saved_today", true).apply()
        savedToday = true
    }

    val avg = values.average().roundToInt()
    val level = overallLevel(xp)
    val progress = xpIntoLevel(xp) / 1000f
    MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF090B10), surface = Color(0xFF141823), primary = Color(0xFF8C7CFF), secondary = Color(0xFF57D9C1))) {
        Scaffold(containerColor = Color(0xFF090B10), bottomBar = {
            NavigationBar(containerColor = Color(0xFF11141C)) {
                listOf("الشخصية","اليوم","التطور").forEachIndexed { i, t -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("🧙","📝","📈")[i]) }, label = { Text(t) }) }
            }
        }) { pad ->
            when (tab) {
                0 -> Home(pad, name, level, progress, avg, mood, streak, values)
                1 -> Daily(pad, values, mood, savedToday, { i, v -> values = values.toMutableList().also { it[i] = v } }, { mood = it }, { saveDay() })
                2 -> Progress(pad, values, xp, level)
            }
        }
    }
}

@Composable private fun Home(pad: PaddingValues, name: String, level: Int, progress: Float, avg: Int, mood: Int, streak: Int, values: List<Int>) {
    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        item { Text("شخصيتي", fontSize = 31.sp, fontWeight = FontWeight.Bold); Text("رحلتك الواقعية تتحول إلى شخصية RPG", color = Color.LightGray) }
        item { Card(colors = CardDefaults.cardColors(Color(0xFF151923)), shape = RoundedCornerShape(28.dp)) { Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$name  •  المستوى $level", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("🔥 سلسلة $streak يوم", color = Color(0xFF57D9C1))
            Spacer(Modifier.height(6.dp)); RPGCharacter(avg, mood); Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth())
            Text("${(progress * 1000).roundToInt()} / 1000 XP", color = Color.LightGray)
        } } }
        item { Text("إحصائياتك الواقعية", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(categories.chunked(2)) { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { row.forEach { c -> StatCard(emojis[categories.indexOf(c)], c, values[categories.indexOf(c)]) } } }
    }
}

@Composable private fun RPGCharacter(avg: Int, mood: Int) {
    Canvas(Modifier.fillMaxWidth().height(285.dp)) {
        val cx = size.width / 2; val growth = 0.82f + avg / 250f; val head = 56f * growth; val bodyW = 88f * growth; val bodyH = 105f * growth; val top = 42f
        drawOval(Color(0x44000000), Rect(cx - 75, top + bodyH + 145, cx + 75, top + bodyH + 170))
        drawCircle(Color(0xFFFFD1B3), head, Offset(cx, top + head))
        drawRoundRect(Color(0xFF49342C), Rect(cx - head, top - 7, cx + head, top + head * 0.72f), 24f)
        drawRoundRect(if (avg >= 70) Color(0xFF6C57E8) else Color(0xFF485166), Rect(cx - bodyW/2, top + head*1.45f, cx + bodyW/2, top + head*1.45f + bodyH), 28f)
        drawRoundRect(Color(0xFF29303E), Rect(cx - bodyW/2 + 9, top + head*1.45f + bodyH, cx - 5, top + head*1.45f + bodyH + 75), 18f)
        drawRoundRect(Color(0xFF29303E), Rect(cx + 5, top + head*1.45f + bodyH, cx + bodyW/2 - 9, top + head*1.45f + bodyH + 75), 18f)
        drawCircle(Color.Black, 6f, Offset(cx - 18, top + head + 7)); drawCircle(Color.Black, 6f, Offset(cx + 18, top + head + 7))
        if (mood >= 75) { drawCircle(Color(0xFF57D9C1), 9f, Offset(cx, top - 23)) }
        if (avg >= 80) { drawCircle(Color(0xFFFFD45A), 8f, Offset(cx - 65, top + 35)); drawCircle(Color(0xFFFFD45A), 8f, Offset(cx + 65, top + 35)) }
    }
}

@Composable private fun StatCard(icon: String, title: String, value: Int) { Card(Modifier.weight(1f), colors = CardDefaults.cardColors(Color(0xFF151923)), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(14.dp)) { Text(icon, fontSize = 24.sp); Text(title, fontWeight = FontWeight.Bold); Text("LVL ${levelOf(value)}", color = Color(0xFF8C7CFF)); LinearProgressIndicator(progress = { value / 100f }, Modifier.fillMaxWidth().padding(top = 7.dp)) } } }

@Composable private fun Daily(pad: PaddingValues, values: List<Int>, mood: Int, saved: Boolean, onChange: (Int, Int) -> Unit, onMood: (Int) -> Unit, onSave: () -> Unit) {
    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Text("تسجيل اليوم", fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("قيّم واقعك كما هو، لا كما تتمنى أن يكون.", color = Color.LightGray) }
        item { Card(colors = CardDefaults.cardColors(Color(0xFF151923)), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Text("المزاج", fontWeight = FontWeight.Bold); Slider(value = mood.toFloat(), onValueChange = { onMood(it.roundToInt()) }, valueRange = 0f..100f); Text("$mood%") } } }
        items(categories) { c -> val i = categories.indexOf(c); Column { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("${emojis[i]}  $c", fontSize = 17.sp, fontWeight = FontWeight.SemiBold); Text("${values[i]}%", color = Color(0xFF8C7CFF)) }; Slider(value = values[i].toFloat(), onValueChange = { onChange(i, it.roundToInt()) }, valueRange = 0f..100f) } }
        item { Button(onClick = onSave, enabled = !saved, Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) { Text(if (saved) "تم حفظ اليوم ✓" else "حفظ يومي + اكتساب XP", fontSize = 17.sp) } }
    }
}

@Composable private fun Progress(pad: PaddingValues, values: List<Int>, xp: Int, level: Int) { LazyColumn(Modifier.padding(pad).fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
    item { Text("التطور", fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("المستوى الكلي $level  •  $xp XP", fontSize = 19.sp); Text("كل جانب يتطور بشكل مستقل.", color = Color.LightGray) }
    items(categories) { c -> val i = categories.indexOf(c); Card(colors = CardDefaults.cardColors(Color(0xFF151923)), shape = RoundedCornerShape(18.dp)) { Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Text(emojis[i], fontSize = 25.sp); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(c, fontWeight = FontWeight.Bold); Text("المستوى ${levelOf(values[i])}  •  ${values[i]} / 100"); LinearProgressIndicator(progress = { values[i] / 100f }, Modifier.fillMaxWidth().padding(top = 5.dp)) } } } }
} }
